# IPT logo and official image assets

The user-supplied Industrial Power Tech logo is stored locally as `ipt-logo-transparent.png`. The source raster's black background has been removed, transparent outer margins have been cropped, and the original logo colors/proportions are preserved. This same file is used in the header, mobile navigation and footer. No white plate, background fill, border or shadow is applied behind the logo.

Primary IPT photography remains referenced from the company's existing public website rather than replaced with unrelated imagery.
