(() => {
  'use strict';

  const body = document.body;
  const header = document.querySelector('.site-header');
  const menuButton = document.querySelector('[data-menu-open]');
  const closeButton = document.querySelector('[data-menu-close]');
  const backdrop = document.querySelector('.drawer-backdrop');
  const drawer = document.querySelector('.mobile-drawer');
  let lastFocused = null;

  const focusableSelector = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

  function openMenu() {
    if (!drawer) return;
    lastFocused = document.activeElement;
    body.classList.add('menu-open');
    menuButton?.setAttribute('aria-expanded', 'true');
    drawer.setAttribute('aria-hidden', 'false');
    const first = drawer.querySelector(focusableSelector);
    window.setTimeout(() => first?.focus(), 20);
  }

  function closeMenu() {
    body.classList.remove('menu-open');
    menuButton?.setAttribute('aria-expanded', 'false');
    drawer?.setAttribute('aria-hidden', 'true');
    lastFocused?.focus?.();
  }

  menuButton?.addEventListener('click', openMenu);
  closeButton?.addEventListener('click', closeMenu);
  backdrop?.addEventListener('click', closeMenu);

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && body.classList.contains('menu-open')) closeMenu();
    if (event.key !== 'Tab' || !body.classList.contains('menu-open') || !drawer) return;
    const focusable = [...drawer.querySelectorAll(focusableSelector)].filter(el => !el.hasAttribute('hidden'));
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault(); last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault(); first.focus();
    }
  });

  document.querySelectorAll('.mobile-accordion').forEach((button) => {
    button.addEventListener('click', () => {
      const item = button.closest('li');
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      item?.classList.toggle('is-open', !expanded);
    });
  });

  document.querySelectorAll('.mobile-nav a').forEach((link) => {
    link.addEventListener('click', closeMenu);
  });

  let ticking = false;
  const updateHeader = () => {
    if (!header) return;
    header.classList.toggle('is-sticky', window.scrollY > 28);
    ticking = false;
  };
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(updateHeader);
      ticking = true;
    }
  }, { passive: true });
  updateHeader();

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reveals = document.querySelectorAll('.reveal');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    reveals.forEach(el => el.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -32px' });
    reveals.forEach(el => revealObserver.observe(el));
  }

  document.querySelectorAll('[data-static-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      const endpoint = form.getAttribute('action');
      if (!endpoint || endpoint === '#') {
        event.preventDefault();
        const note = form.querySelector('[data-form-status]');
        if (note) {
          note.textContent = 'Form UI is ready. Add your Formspree, Web3Forms, EmailJS, or other static endpoint in the form action before going live.';
          note.setAttribute('role', 'status');
          note.focus?.();
        }
      }
    });
  });

  const current = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  document.querySelectorAll('[data-nav-link]').forEach(link => {
    const href = (link.getAttribute('href') || '').split('/').pop().toLowerCase();
    if (href && href === current) link.setAttribute('aria-current', 'page');
  });

  const year = document.querySelector('[data-year]');
  if (year) year.textContent = String(new Date().getFullYear());
})();
